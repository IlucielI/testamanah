<?php $__env->startSection('contents'); ?>
    <div class="container-fluid">
        <div class="container w-75 text-dark mt-5">
            <div class="row">
                <div class="col-6">
                    <img src="/img/<?php echo e($product->image); ?>" alt="image product" width="100%" height="100%">
                </div>
                <div class="col-6">
                    <h3 class="text-primary"><?php echo e($product->name); ?></h3>
                    <h3 class="text-primary"><?php echo e($product->price); ?></h3>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/templete_backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testamanah\resources\views/backend/products/detail.blade.php ENDPATH**/ ?>