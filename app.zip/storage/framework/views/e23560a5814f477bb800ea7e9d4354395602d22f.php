<?php $__env->startSection('contents'); ?>
  <div class="card-deck">
    <?php $__currentLoopData = $data["products"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card" style="width: 18rem;">
        <div class="container-img" style="height:300px">
            <a href=""><img src="/img/<?php echo e($product->image); ?>" class="card-img-top" alt="image product" width="100%" height="100%"></a>
        </div>
          <div class="card-body">
            <h2 class="card-title text-center"><?php echo e($product->name); ?></h2>
            <h4 class="card-title text-center text-danger"><?php echo e($product->price); ?></h4>
              <button type="button" class="btn btn-info">Detail</button>
          </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/templete_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testamanah\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>