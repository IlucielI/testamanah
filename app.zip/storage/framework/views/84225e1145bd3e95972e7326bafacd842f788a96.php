<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="icon" href="<?php echo e(URL::asset('icon.ico')); ?>">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <link rel="stylesheet" href="<?php echo e(URL::asset('sweetalert/sweetalert2.min.css')); ?>">
  <title><?php echo e($data["title"]); ?></title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">Bayu Anugerah</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
        </div>
        <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="nav-link disabled"  href="<?php echo e(url ('/')); ?>">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php if(Request::segment( 1 ) == 'products'): ?> active <?php endif; ?>" href="/products">products</a>
            </li>
        </ul>
        <?php if(auth()->guard()->guest()): ?>
        <a href="/login" style="text-decoration: none">
            <button class="btn btn-outline-info rounded-pill" type="button">Login</button>
        </a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <div class="btn-group">
            <button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                Hi, <?php echo e(Auth::user()->name); ?>

            </button>
                <div class="dropdown-menu" style="left: -30px;">
                    <form action="/logout" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item">Logout</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
      </div>
    </div>
  </nav>
  <div class="container mt-5">
      <?php echo $__env->yieldContent('contents'); ?>

  </div>

  


  <script src="<?php echo e(URL::asset('jquery.min.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  <script src="<?php echo e(URL::asset('sweetalert/sweetalert2.all.min.js')); ?>"></script>
  <?php echo $__env->yieldContent('script'); ?>
  <?php if(Session::has('message')): ?>
        <script>
            Swal.fire(
                'Success!',
                '<?php echo e(Session::get('message')); ?>',
                'success')
        </script>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            Swal.fire(
                'Error!',
                '<?php echo e(Session::get('error')); ?>',
                'error')
        </script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\testamanah\resources\views/layouts/templete_frontend.blade.php ENDPATH**/ ?>